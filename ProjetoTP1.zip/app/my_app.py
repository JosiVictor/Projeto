import streamlit as st
import pandas as pd

# Título do projeto
st.title('Previsão de Calorias Queimadas Durante Exercícios Físicos')

# Descrição do problema de negócio e objetivos do projeto
st.header('Descrição do Problema e Objetivos')
st.write("""
Este projeto visa desenvolver uma aplicação para prever as calorias queimadas durante exercícios físicos. A solução tem como objetivo oferecer recomendações personalizadas com base na quantidade de calorias que o usuário pode queimar durante uma atividade física específica. O projeto está alinhado aos princípios da Agenda 2030 e aos pilares ESG, buscando promover a saúde e o bem-estar.

### Objetivos do Projeto
- **Prever a queima de calorias** durante diferentes tipos de exercícios físicos.
- **Sugerir atividades físicas** baseadas na quantidade de calorias previstas.
- **Fornecer um dashboard interativo** para visualização dos dados e recomendações.

""")

# Links úteis
st.header('Links Úteis')
st.write("""
- [Iniciativas e Fontes de Inspiração](https://www.un.org/sustainabledevelopment/)
""")

# Carregar e exibir amostras dos dados
st.header('Amostras dos Dados')


calories_df = pd.read_csv('data/burned_calories.csv')
exercise_df = pd.read_csv('data/exercise.csv')

# Exibir amostras dos dados
st.subheader('Dados de Calorias Queimadas')
st.write(calories_df.head())

st.subheader('Dados de Atividades Físicas')
st.write(exercise_df.head())


